package com.knowing.inc.reportGenerate.utils;

import java.io.*;
import com.aspose.words.*;
import org.junit.Test;

public class Doc2Pdf {
    public static void doc2pdf(String Address,String pdffile,String lisenceAddress) {
        try {
            InputStream is = new FileInputStream(lisenceAddress); //  license.xml应放在..\WebRoot\WEB-INF\classes路径下
            License aposeLic = new License();
            aposeLic.setLicense(is);
            File file = new File(pdffile);  //新建一个空白pdf文档
            FileOutputStream os = new FileOutputStream(file);
            Document doc = new Document(Address);                    //Address是将要被转化的word文档
            doc.save(os, SaveFormat.PDF);//全面支持DOC, DOCX, OOXML, RTF HTML, OpenDocument, PDF, EPUB, XPS, SWF 相互转换
            os.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
